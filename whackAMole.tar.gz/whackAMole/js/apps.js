var game = new Game();
game.startGame();
