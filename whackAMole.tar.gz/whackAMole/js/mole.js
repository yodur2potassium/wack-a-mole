function Mole() {
  this.createHtmlElement();
}

// Setters :
Mole.prototype.createHtmlElement = function() {
 this._htmlElement = $('<img>');
 this._htmlElement.attr('src', 'img/mole.png');
}
